package povertyPackage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Report{
	
	public static void main(String[] args) throws IOException {
		
		// file pulling data from
		File file = new File("C:\\usr\\code\\java\\target.txt");
		
		// buffered reader to read the incoming file
		BufferedReader reader = null;
		
		// counter for number of records read
		int count = 0;
		
		// try completing main task of class
		try {
			
			// try to place the file into a BufferedReader
			reader = new BufferedReader(new FileReader(file));
			
			// write first line to console
			System.out.println("File: " + file + '\n');
			
			// write column headers to the console
			System.out.println("State" + '\t' + "Total_Kids" + '\t' + "In_Poverty" + '\t' + "Poverty_Percentage");
			
			// read file per line
			String line = reader.readLine();
			
			// loop through file
			while (line != null) {
				
				// write line of file to the console
				System.out.println(line);
				
				// increment the counter
				count++;
				
				// read next line of file
				line = reader.readLine();
			}
			
			// add a space after records to make report look nicer
			if (line == null) {
				System.out.println('\n');
			}
			
		} catch(Exception e) {
			
			// catch all exceptions that may occur
			System.err.println("An unexpected error occured.");
			
		} finally {
			
			// close the BufferedReader
			reader.close();
			
			// print the total number of records read
			System.out.println("Number of records read: " + count);
		}
	}
}




