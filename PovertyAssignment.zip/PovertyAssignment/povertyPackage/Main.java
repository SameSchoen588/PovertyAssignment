package povertyPackage;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
import java.io.File;

public class Main {
	
		// decimal format for file
		static DecimalFormat df = new DecimalFormat("##.##");
	
		// method for reading each line of file
		public static String pullData(String fileLine, int tab) {
			
			// place holder variables
			String data = "-1";
			int tabs = 0;
			char[] dataArray = new char[7];
			int arrayPosition = 0;
			char ch;
			
			// loop through line of file 
			for (int i = 0; i < fileLine.length(); i++) {
				
				// set variable to equal current char
				ch = fileLine.charAt(i);
				
				//System.out.println("What ch holds: " + ch);
				
				// if current char is a '\t' tab
				if (ch == '\t') {
					
					// count tab
					tabs++;
					
					//System.out.println("Number of tabs: " + tabs);
				}
				
				// if tab == tabs
				if (tab == tabs) {
					
					// if char is a digit
					if (Character.isDigit(fileLine.charAt(i))) {
						
						// add to dataArray
						dataArray[arrayPosition] = ch;
						
						// increment arrayPostion
						arrayPosition++;
					}		
				}
			}
			
			// convert dataArray to string data
			data = new String(dataArray);
			
			// trim any extra white space from empty characters in character array
			data = data.trim();
			
			// return data
			return data;
		}
		
		public static void main(String[] args) throws IOException {
			
		// set up file reading tools for source file
		File file = new File("C:\\usr\\code\\district.txt");
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		BufferedReader reader = null;
		
		// set up file reading tools for formatted file
		File file2 = new File("C:\\usr\\code\\java\\target.txt");
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		
		// integer for Main process
		int count = -2;
		int TOTAL = 5;
		int POVERTY = 6;
		
		// collections of data for the report
		String currentState = "xx";
		int total_per_district = 0;
		int poverty_per_district = 0;
		
		// hold results of percentage formula
		double percentage_of_poverty;
		
			// try completing the main tasks of the program
			try {
							
				// try to place file into a FileInputStream
				fis = new FileInputStream(file);
				// try to place FileInputStream into a BufferedInputStream
				bis = new BufferedInputStream(fis);
				// try to create a buffered reader to read file
				reader = new BufferedReader(new FileReader(file));
				
				// try to place file into a FileInputStream
				fos = new FileOutputStream(file2);
				// try to place FileOutputStream into a BufferedWriter
				bw = new BufferedWriter(new OutputStreamWriter(fos));
				
				// read file per line
				String line = reader.readLine();
				
				// while not the end of the file
				while (line != null) {
				
					// if we are past column header section
					if (count > 0) {
						
						// collect state abbreviation at start of current line
						char p1 = line.charAt(0);
						char p2 = line.charAt(1);
						String abr = new StringBuilder().append(p1).append(p2).toString();
						
						// if this is the first instance of this state
						if (!(abr.equals(currentState))) {
							
							// if first instance of first state Alabama
							if (count > 1) {
								
								// create the percentage in poverty
								percentage_of_poverty = (((double)poverty_per_district/(double)total_per_district)*100);
								
								// write data to state file
								bw.write(currentState + '\t' + NumberFormat.getNumberInstance(Locale.US).format(total_per_district) + 
										"   " + '\t' + NumberFormat.getNumberInstance(Locale.US).format(poverty_per_district) + 
										"   " + '\t' + "%" + df.format(percentage_of_poverty));
								
								// start a new line for next record
								bw.newLine();
								
								// clear total and poverty amounts
								total_per_district = 0;
								poverty_per_district = 0;
							}
							
							// set the currentState value to value of abr
							currentState = abr;
							
						}
						
						// pull data from line of file
						String s1 = pullData(line, TOTAL);
						String s2 = pullData(line, POVERTY);
						
						// convert strings to integers
						double totalKids = Integer.parseInt(s1);
						double povertyKids = Integer.parseInt(s2);
						
						// concatenate the populations
						total_per_district += totalKids;
						poverty_per_district += povertyKids;
						
					}
					
					// while in the loop read next line of file
					line = reader.readLine();
						
					// increment the counter
					count++;
				}
				
				// if end of file
				if (line == null) {
					
					// create the percentage in poverty
					percentage_of_poverty = (((double)poverty_per_district/(double)total_per_district)*100);
					
					// write the last data to target file
					bw.write(currentState + '\t' + NumberFormat.getNumberInstance(Locale.US).format(total_per_district) + 
							"   " + '\t' + NumberFormat.getNumberInstance(Locale.US).format(poverty_per_district) + 
							"   " + '\t' + "%" + df.format(percentage_of_poverty));
				}
			
			} catch (IOException e) {
				
				// catch the likely IOException
				System.err.println("Caught IOException: " + e.getMessage());
			
			} catch(Exception e) {
				
				// catch all other exceptions that may occur
				System.err.println("An unexpected error occured.");
				
			} finally {
				
				// close out all streams
				reader.close();
				bw.close();
				fos.close();
				bis.close();
				fis.close();
				System.out.println("Number of records read: " + (count - 1));
			}	
		}
}	




